package com.pizza.test;

import com.pizza.abstractFactory.NonVegPizzaFactory;
import com.pizza.abstractFactory.PizzaFactory;
import com.pizza.abstractFactory.VegPizzaFactory;
import com.pizza.beans.Pizza;

public class PizzaClient {
	
	
	public static void main(String[] args) {
		
		Pizza vegPizza = PizzaFactory.createPizza(new VegPizzaFactory("Mozrella", "Capsicum,onion,tomato,corn", "Hand Toast"));
		
		Pizza nonVegPizza = PizzaFactory.createPizza(new NonVegPizzaFactory("Mozrella", "Onion,tomato,chicken sausage", "Thin Crust"));
		
		System.out.println(vegPizza.toString());
		System.out.println(nonVegPizza.toString());
	}

}
