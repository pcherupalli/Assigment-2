package com.pizza.abstractFactory;

import com.pizza.beans.Pizza;

public class PizzaFactory  {
    
	public static Pizza createPizza(PizzaAbstractFactory obj) {
		return obj.createPizza();
	}
}
