package com.pizza.abstractFactory;

import com.pizza.beans.Pizza;
import com.pizza.beans.VegPizza;

public class VegPizzaFactory implements PizzaAbstractFactory {
    
	private String cheese;
	private String toppings;
	private String crust;
	
	
	public VegPizzaFactory(String cheese, String toppings, String crust) {
		this.cheese = cheese;
		this.toppings = toppings;
		this.crust = crust;
	}


	@Override
	public Pizza createPizza() {
		// TODO Auto-generated method stub
		return new VegPizza(this.cheese, this.toppings,this.crust);
	}

}
