package com.pizza.abstractFactory;

import com.pizza.beans.NonVegPizza;
import com.pizza.beans.Pizza;

public class NonVegPizzaFactory implements PizzaAbstractFactory {

	private String cheese;
	private String toppings;
	private String crust;
	
	
	
	public NonVegPizzaFactory(String cheese, String toppings, String crust) {
		this.cheese = cheese;
		this.toppings = toppings;
		this.crust = crust;
	}



	@Override
	public Pizza createPizza() {
		// TODO Auto-generated method stub
		return new NonVegPizza(this.cheese, this.toppings, this.crust);
	}

}
