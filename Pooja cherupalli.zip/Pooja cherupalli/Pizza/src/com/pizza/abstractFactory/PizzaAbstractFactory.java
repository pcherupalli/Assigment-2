package com.pizza.abstractFactory;

import com.pizza.beans.Pizza;

public interface PizzaAbstractFactory {
	
	public Pizza createPizza();

}
