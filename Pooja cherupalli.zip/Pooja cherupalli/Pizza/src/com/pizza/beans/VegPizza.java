package com.pizza.beans;

public class VegPizza implements Pizza {
    
	private String cheese;
	private String toppings;
	private String crust;
	
	
	
	public VegPizza(String cheese, String toppings, String crust) {
		this.cheese = cheese;
		this.toppings = toppings;
		this.crust = crust;
	}

	@Override
	public String getCheese() {
		// TODO Auto-generated method stub
		return this.cheese;
	}

	@Override
	public String getToppings() {
		// TODO Auto-generated method stub
		return this.toppings;
	}

	
	@Override
	public String getCrust() {
		// TODO Auto-generated method stub
		return this.crust;
	}
	
	@Override
	public String toString() {
		return "VegPizza [cheese=" + cheese + ", toppings=" + toppings + ", crust=" + crust + "]";
	}


}
