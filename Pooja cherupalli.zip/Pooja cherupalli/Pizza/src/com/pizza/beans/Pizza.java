package com.pizza.beans;

public interface Pizza {
	
	
	public String getCheese();
	
	public String getToppings();
	
	public String getCrust();

}
